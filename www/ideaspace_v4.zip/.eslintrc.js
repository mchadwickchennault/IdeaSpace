module.exports = {
    "extends": "airbnb",
}